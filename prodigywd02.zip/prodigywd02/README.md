# ProdigyWD02

A Pen created on CodePen.io. Original URL: [https://codepen.io/Nandini-Vallavan/pen/jOowPoO](https://codepen.io/Nandini-Vallavan/pen/jOowPoO).

